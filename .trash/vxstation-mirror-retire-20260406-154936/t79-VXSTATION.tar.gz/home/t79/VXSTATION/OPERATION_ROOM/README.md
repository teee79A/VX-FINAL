# OPERATION_ROOM

Live operations room for execution control, runtime health, and operator actions.

## Surfaces

- `live_control_surface`
- `runtime_status`
- `operator_actions`
- `execution_monitoring`
- `evidence_linked_room_state`

## Launch

`/home/t79/VXSTATION/kitty/bin/kitty-operation-room.sh --reset`

## Report

`/home/t79/VXSTATION/kitty/bin/operation-room-report.sh`
