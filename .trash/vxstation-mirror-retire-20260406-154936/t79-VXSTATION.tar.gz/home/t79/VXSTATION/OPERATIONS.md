# VXSTATION Operations

VXSTATION is the local root workspace for daily AI + engineering operations.

## Scope

- intake
- daily operations
- build operations
- release operations
- cloud operations
- planning and decisions
- reporting and exports

## Boundary

VXSTATION is not the live runtime authority.
Runtime authority remains inside VYRDX runtime boundaries.
