# VXSTATION

Daily operational station for planning, audits, migration, release prep, and cloud operations.

Correction (2026-03-27):

- `VXSTATION` is an internal VYRDON directory/layer.
- `VXSTATION` is not a domain, hostname, or standalone public surface.

- `daily_ops/`
- `build_ops/`
- `release_ops/`
- `cloud_ops/`
- `runtime_audits/`
- `migration/`
- `reports/`

Rule: this is the operator surface, not the canonical runtime state store.
