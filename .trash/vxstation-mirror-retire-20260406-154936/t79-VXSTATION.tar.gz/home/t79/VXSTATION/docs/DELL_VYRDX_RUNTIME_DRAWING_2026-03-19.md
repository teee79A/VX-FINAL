DESIGN FROZEN
PRODUCTION FINALIZATION PENDING VERIFICATION

# DELL / VYRDX Runtime Drawing

## Law

- `VYRDX` is the only runtime.
- `VYRDX` is the cloud runtime envelope on `DigitalOcean`.
- `VYRDOX` is the sealed internal root inside `VYRDX`.
- `VYRDOX` must never be publicly exposed.
- `VYRDOX` root exposes only `room`, `logic`, and `power`.
- `room` is internal doctrine, not a public AI-facing path.
- `runner` lives on `DELL` desktop.
- `VS Code`, `VS Code Insiders`, `Cursor`, and the ensemble app are operator tools, not runtime.

## Drawing

```text
DELL
├─ Desktop / Operator Side
│  ├─ runner
│  ├─ VS Code
│  ├─ VS Code Insiders
│  ├─ Cursor
│  └─ ensemble app
│
└─ VYRDX Runtime Root
   └─ /opt/vyrdx
      └─ vyrdox
         ├─ room
         │  ├─ common
         │  ├─ memory
         │  ├─ rag
         │  ├─ vector
         │  ├─ archive
         │  └─ agents
         │     ├─ codex
         │     ├─ claude
         │     ├─ deepseek-v3
         │     ├─ deepseek-r1
         │     ├─ qwen-14b
         │     ├─ qwen-8b
         │     └─ gpt-oss-20b
         ├─ logic
         │  ├─ law
         │  ├─ identity
         │  ├─ config
         │  ├─ contracts
         │  ├─ registry
         │  ├─ routing
         │  ├─ layers
         │  └─ reports
         └─ power
            ├─ runtime
            ├─ health
            ├─ orchestration
            ├─ tools
            ├─ storage
            ├─ mcp
            ├─ adapters
            ├─ terminal
            ├─ services
            └─ apps
```

## Agent Paths

- `/opt/vyrdx/vyrdox/room/agents/codex`
- `/opt/vyrdx/vyrdox/room/agents/claude`
- `/opt/vyrdx/vyrdox/room/agents/deepseek-v3`
- `/opt/vyrdx/vyrdox/room/agents/deepseek-r1`
- `/opt/vyrdx/vyrdox/room/agents/qwen-14b`
- `/opt/vyrdx/vyrdox/room/agents/qwen-8b`
- `/opt/vyrdx/vyrdox/room/agents/gpt-oss-20b`

## What Is Not Runtime

- desktop runner
- VS Code
- VS Code Insiders
- Cursor
- ensemble app

## Room Lock Rule

- lock the room after path truth is clean
- do not mix `/srv/vyrdon/ai-room` into the runtime doctrine
- runtime path truth for current design is `/opt/vyrdx`
- internal root path truth for current design is `/opt/vyrdx/vyrdox`
- room path truth for current design is `/opt/vyrdx/vyrdox/room`
