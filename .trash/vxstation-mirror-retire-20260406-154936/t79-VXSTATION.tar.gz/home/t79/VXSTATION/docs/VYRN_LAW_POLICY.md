# VYRN Law Policy

VYRN operates with sealed boundaries, clear ownership, and deliberate execution.

The workspace may guide, review, and prepare, but it must not blur system ownership or expose internal land by accident.

Every change must have a path, a reason, and a responsible owner.

Boot files prepare the lane. Settings files control the lane. Law files govern the lane.

VYRDOX remains the build land. VS Code remains an external workspace layer.
