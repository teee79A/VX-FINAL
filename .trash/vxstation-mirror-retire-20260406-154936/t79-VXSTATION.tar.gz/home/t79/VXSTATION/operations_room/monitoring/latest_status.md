# Operations Room Registry Status

- Generated: 2026-03-27T12:59:58Z
- Overall status: degraded
- Missing components: 4

## Summary

- engine: total=7 online=7 missing=0
- adapter: total=12 online=12 missing=0
- hook: total=28 online=28 missing=0
- mcp_server: total=6 online=6 missing=0
- room: total=5 online=5 missing=0
- electric: total=10 online=6 missing=4

## Missing Components

- electric.qdrant (electric): missing @ $PATH
- electric.livekit (electric): missing @ $PATH
- electric.coturn (electric): missing @ $PATH
- electric.piper (electric): missing @ $PATH
