#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import shutil
import subprocess
import sys

OPS_ROOT = Path("/home/t79/VXSTATION/operations_room")
REGISTRY_FILE = OPS_ROOT / "registry" / "component_registry.json"
STATUS_JSON = OPS_ROOT / "monitoring" / "latest_status.json"
STATUS_MD = OPS_ROOT / "monitoring" / "latest_status.md"
BUILD_SCRIPT = OPS_ROOT / "scripts" / "build_component_registry.py"


def ensure_registry() -> None:
    if REGISTRY_FILE.is_file():
        return
    subprocess.run([sys.executable, str(BUILD_SCRIPT)], check=True)


def evaluate_component(component: dict[str, object]) -> dict[str, object]:
    ctype = str(component.get("type", "unknown"))
    result = dict(component)
    if ctype in {"engine", "adapter", "hook", "mcp_server", "room"}:
        path = Path(str(component.get("location", "")))
        ok = path.exists()
        result["runtime_status"] = "online" if ok else "missing"
        result["resolved_location"] = str(path)
        return result
    if ctype == "electric":
        binary = str(component.get("binary", ""))
        detected = shutil.which(binary)
        ok = detected is not None
        result["runtime_status"] = "online" if ok else "missing"
        result["resolved_location"] = detected or "$PATH"
        return result
    result["runtime_status"] = "unknown"
    result["resolved_location"] = str(component.get("location", ""))
    return result


def build_markdown(status: dict[str, object]) -> str:
    lines: list[str] = []
    lines.append("# Operations Room Registry Status")
    lines.append("")
    lines.append(f"- Generated: {status['generated_at']}")
    lines.append(f"- Overall status: {status['overall_status']}")
    lines.append(f"- Missing components: {status['missing_count']}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    summary = status["summary"]
    for key in ("engine", "adapter", "hook", "mcp_server", "room", "electric"):
        entry = summary.get(key, {"total": 0, "online": 0, "missing": 0})
        lines.append(f"- {key}: total={entry['total']} online={entry['online']} missing={entry['missing']}")
    lines.append("")
    lines.append("## Missing Components")
    lines.append("")
    missing = [c for c in status["components"] if c["runtime_status"] != "online"]
    if not missing:
        lines.append("- none")
    else:
        for component in missing:
            lines.append(
                f"- {component['id']} ({component['type']}): {component['runtime_status']} @ {component['resolved_location']}"
            )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    ensure_registry()
    registry = json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
    evaluated = [evaluate_component(component) for component in registry.get("components", [])]

    summary: dict[str, dict[str, int]] = {}
    missing_count = 0
    for item in evaluated:
        ctype = str(item.get("type", "unknown"))
        bucket = summary.setdefault(ctype, {"total": 0, "online": 0, "missing": 0})
        bucket["total"] += 1
        if item.get("runtime_status") == "online":
            bucket["online"] += 1
        else:
            bucket["missing"] += 1
            missing_count += 1

    status = {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "registry_path": str(REGISTRY_FILE),
        "overall_status": "healthy" if missing_count == 0 else "degraded",
        "missing_count": missing_count,
        "summary": summary,
        "components": evaluated,
    }

    STATUS_JSON.parent.mkdir(parents=True, exist_ok=True)
    STATUS_JSON.write_text(json.dumps(status, indent=2), encoding="utf-8")
    STATUS_MD.write_text(build_markdown(status), encoding="utf-8")

    print(json.dumps(status, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
