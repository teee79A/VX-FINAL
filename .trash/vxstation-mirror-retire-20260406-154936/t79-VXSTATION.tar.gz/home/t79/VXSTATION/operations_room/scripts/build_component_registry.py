#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import shutil

VYRDX_ROOT = Path("/home/t79/VYRDON/VYRDX")
OPS_ROOT = Path("/home/t79/VXSTATION/operations_room")
REGISTRY_FILE = OPS_ROOT / "registry" / "component_registry.json"


def _component_id(prefix: str, name: str) -> str:
    return f"{prefix}.{name.replace('/', '.').replace('-', '_')}"


def _scan_python_components(base: Path, category: str) -> list[dict[str, object]]:
    components: list[dict[str, object]] = []
    for path in sorted(base.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        if path.name == "__init__.py":
            continue
        rel = path.relative_to(VYRDX_ROOT)
        name = path.stem
        components.append(
            {
                "id": _component_id(category, name),
                "type": category,
                "name": name,
                "location": str(path),
                "relative_location": str(rel),
                "status": "registered",
            }
        )
    return components


def _scan_mcp_servers(base: Path) -> list[dict[str, object]]:
    components: list[dict[str, object]] = []
    for server_dir in sorted(path for path in base.iterdir() if path.is_dir()):
        server_file = server_dir / "server.py"
        manifest_file = server_dir / "manifest.json"
        components.append(
            {
                "id": _component_id("mcp_server", server_dir.name),
                "type": "mcp_server",
                "name": server_dir.name,
                "location": str(server_file),
                "manifest": str(manifest_file),
                "status": "registered",
            }
        )
    return components


def _scan_rooms(base: Path) -> list[dict[str, object]]:
    components: list[dict[str, object]] = []
    for room_dir in sorted(path for path in base.iterdir() if path.is_dir()):
        components.append(
            {
                "id": _component_id("room", room_dir.name),
                "type": "room",
                "name": room_dir.name,
                "location": str(room_dir),
                "status": "registered",
            }
        )
    return components


def _electric_components() -> list[dict[str, object]]:
    targets = [
        ("postgresql", "psql"),
        ("redis", "redis-server"),
        ("qdrant", "qdrant"),
        ("livekit", "livekit-server"),
        ("coturn", "turnserver"),
        ("faster_whisper", "python3"),
        ("piper", "piper"),
        ("xtts", "python3"),
        ("openvoice", "python3"),
        ("rvc_optional", "python3"),
    ]
    components: list[dict[str, object]] = []
    for name, binary in targets:
        detected = shutil.which(binary)
        components.append(
            {
                "id": _component_id("electric", name),
                "type": "electric",
                "name": name,
                "binary": binary,
                "location": detected or "$PATH",
                "status": "detected" if detected else "missing",
            }
        )
    return components


def build_registry() -> dict[str, object]:
    engines = _scan_python_components(VYRDX_ROOT / "code/python/engines", "engine")
    adapters = _scan_python_components(VYRDX_ROOT / "code/python/adapters", "adapter")
    hooks = _scan_python_components(VYRDX_ROOT / "runtime/hooks", "hook")
    mcp_servers = _scan_mcp_servers(VYRDX_ROOT / "services/mcp/servers")
    rooms = _scan_rooms(VYRDX_ROOT / "rooms")
    electric = _electric_components()

    registry = {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_roots": {
            "vyrdx": str(VYRDX_ROOT),
            "vxstation_operations_room": str(OPS_ROOT),
        },
        "counts": {
            "engines": len(engines),
            "adapters": len(adapters),
            "hooks": len(hooks),
            "mcp_servers": len(mcp_servers),
            "rooms": len(rooms),
            "electric": len(electric),
        },
        "components": engines + adapters + hooks + mcp_servers + rooms + electric,
    }
    return registry


def main() -> int:
    registry = build_registry()
    REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_FILE.write_text(json.dumps(registry, indent=2), encoding="utf-8")
    print(json.dumps({"status": "written", "path": str(REGISTRY_FILE), "counts": registry["counts"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
