# VXSTATION Operations Room

Central monitoring room for VYRDON component placement, status, and location.

Boundary clarification:

- `VXSTATION` in this context is an internal directory/layer inside VYRDON.
- Any `vxstation.*` identifiers are internal service namespaces, not network hostnames.

Scope:

- engines
- adapters
- runtime hooks
- rooms
- MCP servers
- electric/media stack binaries

Core files:

- `registry/component_registry.json`
- `monitoring/latest_status.json`
- `monitoring/latest_status.md`
- `scripts/build_component_registry.py`
- `scripts/check_component_registry.py`
