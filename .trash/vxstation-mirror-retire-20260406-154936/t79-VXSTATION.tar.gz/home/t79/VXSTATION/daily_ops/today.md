# Daily Ops - Today

## Priorities

- Keep Kitty command bus healthy.
- Keep bridge lanes policy-controlled.
- Keep evidence outputs complete.

## Notes

- Add today decisions and blockers here.
