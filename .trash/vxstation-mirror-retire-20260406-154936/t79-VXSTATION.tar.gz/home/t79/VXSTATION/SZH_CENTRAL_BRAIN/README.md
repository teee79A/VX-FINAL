# SZH_CENTRAL_BRAIN

Central control room for VXSTATION command, policy, orchestration, and evidence.

## Surfaces

- `live_control_surface`
- `runtime_status`
- `operator_actions`
- `execution_monitoring`
- `evidence_linked_room_state`

## Orchestration domains

- `orchestration_logic`
- `policy_routing`
- `state_synthesis`
- `cross_room_coordination`
- `decision_support`

## Launch

`/home/t79/VXSTATION/kitty/bin/kitty-central-brain.sh --reset`

## Report

`/home/t79/VXSTATION/kitty/bin/central-brain-report.sh`
