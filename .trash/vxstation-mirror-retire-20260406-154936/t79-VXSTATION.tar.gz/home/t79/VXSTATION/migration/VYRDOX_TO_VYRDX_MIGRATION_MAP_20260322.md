# VYRDOX to VYRDX Migration Map

## Current Source

- `/home/t79/VYRDON/VYRDOX`
- `/home/t79/VYRDON/VYRDOX/room`
- `/home/t79/VYRDON/VYRDOX/frozen-do-runtime`

## Target Roots

- `/home/t79/AI_ROOM`
- `/home/t79/VXSTATION`
- `/home/t79/ARCHIVE_ROOM`
- `/home/t79/VYRDON/VYRDX`

## Safe Mapping

- `room/agents` -> `/home/t79/AI_ROOM/agents`
- `room/tools` -> `/home/t79/AI_ROOM/tools` or `/home/t79/VYRDON/VYRDX/bin`
- `room/config` -> `/home/t79/VYRDON/VYRDX/config`
- `room/engines` -> `/home/t79/VYRDON/VYRDX/vyrdox/orchestration`
- `room/out` -> `/home/t79/VXSTATION/exports`
- top-level architecture docs -> `/home/t79/VXSTATION/docs`
- `frozen-do-runtime` -> `/home/t79/ARCHIVE_ROOM/retired_structures/frozen-do-runtime`

## Hold Until Cutover

- `.devcontainer`
- `.github`
- `.qodo`
- `.roo`
- `.todo`
- `.vscode`

## Rule

Do not delete `/home/t79/VYRDON/VYRDOX` until the new runtime has absorbed required material and the cutover checklist passes.
